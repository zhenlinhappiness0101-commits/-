import React, { useState, useEffect } from 'react';
import { HistoryItem } from '../types';
import { getHistory, addManualEntry, getTotalPushups } from '../services/storageService';
import { formatDateForHistory, formatFullDate } from '../utils/dateUtils';

interface HistoryViewProps {
  onBack: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ onBack }) => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [manualDate, setManualDate] = useState('');
  const [manualCount, setManualCount] = useState('');

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    const data = getHistory();
    // Sort by date descending
    data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setHistory(data);
  };

  const handleDownload = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "pushup_history.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleAddManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualDate && manualCount) {
      addManualEntry(manualDate, parseInt(manualCount));
      setShowModal(false);
      setManualDate('');
      setManualCount('');
      refreshData();
    }
  };

  return (
    <div className="h-full w-full bg-slate-900 overflow-y-auto p-4 md:p-8">
      <div className="max-w-3xl mx-auto space-y-6 pb-20">
        
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <button onClick={onBack} className="text-cyan-400 hover:text-white transition-colors">
            <i className="fa-solid fa-arrow-left text-xl"></i>
          </button>
          <h1 className="text-2xl font-tech text-white">历史记录档案</h1>
          <div className="w-6"></div> {/* Spacer */}
        </div>

        {/* Stats Card */}
        <div className="bg-gradient-to-r from-blue-900 to-slate-900 p-6 rounded-2xl border border-cyan-500/30 shadow-lg flex justify-between items-center">
            <div>
                <p className="text-slate-400 text-sm">累计总次数</p>
                <p className="text-4xl font-bold text-cyan-400">{getTotalPushups()}</p>
            </div>
             <button 
                onClick={handleDownload}
                className="bg-slate-800 p-3 rounded-full hover:bg-slate-700 text-cyan-300"
                title="Download Data"
             >
               <i className="fa-solid fa-download"></i>
             </button>
        </div>

        {/* Add Button */}
        <button 
          onClick={() => setShowModal(true)}
          className="w-full py-4 rounded-xl border-2 border-dashed border-slate-600 text-slate-400 hover:border-cyan-500 hover:text-cyan-400 transition-all"
        >
          <i className="fa-solid fa-plus mr-2"></i> 补录历史数据
        </button>

        {/* List */}
        <div className="space-y-3">
          {history.length === 0 ? (
            <p className="text-center text-slate-500 mt-10">暂无数据</p>
          ) : (
            history.map((item) => (
              <div key={item.id} className="bg-white/5 p-4 rounded-xl flex justify-between items-center border border-white/5 hover:border-cyan-500/30 transition-colors">
                <div>
                   <p className="text-white font-bold">{formatDateForHistory(item.date)}</p>
                   <p className="text-xs text-slate-500">{new Date(item.timestamp).toLocaleTimeString()}</p>
                </div>
                <div className="text-xl font-mono text-fuchsia-400">
                  +{item.count}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 w-full max-w-sm rounded-2xl p-6 border border-cyan-500/50 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">补录数据</h3>
            <form onSubmit={handleAddManual} className="space-y-4">
              <div>
                <label className="block text-slate-400 text-sm mb-1">日期</label>
                <input 
                  type="date" 
                  required
                  value={manualDate}
                  onChange={e => setManualDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white focus:border-cyan-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-400 text-sm mb-1">个数</label>
                <input 
                  type="number" 
                  required
                  min="1"
                  value={manualCount}
                  onChange={e => setManualCount(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white focus:border-cyan-500 outline-none"
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button 
                  type="button" 
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-3 rounded-lg bg-slate-700 text-white hover:bg-slate-600"
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-3 rounded-lg bg-cyan-600 text-white hover:bg-cyan-500 font-bold"
                >
                  确认
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryView;