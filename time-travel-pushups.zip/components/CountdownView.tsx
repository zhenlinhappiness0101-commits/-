import React, { useEffect, useState } from 'react';

interface CountdownViewProps {
  onComplete: () => void;
}

const CountdownView: React.FC<CountdownViewProps> = ({ onComplete }) => {
  const [count, setCount] = useState(3);

  useEffect(() => {
    if (count === 0) {
      onComplete();
      return;
    }

    const timer = setTimeout(() => {
      setCount(count - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [count, onComplete]);

  // Color mapping for numbers
  const getColors = (num: number) => {
    switch (num) {
      case 3: return "text-green-400 drop-shadow-[0_0_35px_rgba(74,222,128,0.8)]";
      case 2: return "text-yellow-400 drop-shadow-[0_0_35px_rgba(250,204,21,0.8)]";
      case 1: return "text-red-500 drop-shadow-[0_0_35px_rgba(239,68,68,0.8)]";
      default: return "text-white";
    }
  };

  return (
    <div className="h-full w-full flex items-center justify-center bg-slate-950 overflow-hidden relative">
       {/* Animated Background Grid */}
       <div className="absolute inset-0 z-0 opacity-20" 
         style={{
           backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)',
           backgroundSize: '40px 40px'
         }}
       ></div>

       <div className="z-10 animate-bounce">
         {count > 0 && (
           <span className={`text-[12rem] font-black font-tech ${getColors(count)} transition-all duration-300 transform scale-150`}>
             {count}
           </span>
         )}
       </div>
    </div>
  );
};

export default CountdownView;