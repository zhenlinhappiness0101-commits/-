import { HistoryItem } from '../types';

const STORAGE_KEY = 'pushup_time_travel_history';

export const getHistory = (): HistoryItem[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error("Failed to load history", e);
    return [];
  }
};

export const saveHistoryItem = (item: HistoryItem): HistoryItem[] => {
  const current = getHistory();
  const updated = [...current, item];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
};

export const getTotalPushups = (): number => {
  const history = getHistory();
  return history.reduce((acc, item) => acc + item.count, 0);
};

export const addManualEntry = (date: string, count: number): HistoryItem[] => {
  const newItem: HistoryItem = {
    id: Date.now().toString() + Math.random().toString(),
    date: new Date(date).toISOString(),
    count: count,
    timestamp: Date.now()
  };
  return saveHistoryItem(newItem);
};