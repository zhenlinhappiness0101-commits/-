import React, { useState } from 'react';

interface InputViewProps {
  onConfirm: (count: number) => void;
}

const InputView: React.FC<InputViewProps> = ({ onConfirm }) => {
  const [countStr, setCountStr] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const count = parseInt(countStr, 10);
    if (!isNaN(count) && count > 0) {
      onConfirm(count);
    }
  };

  return (
    <div className="h-full w-full flex flex-col items-center justify-center p-6 bg-slate-900 relative">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1470&auto=format&fit=crop')] bg-cover bg-center opacity-20"></div>
      
      <div className="z-10 w-full max-w-md bg-white/5 backdrop-blur-xl p-8 rounded-2xl border border-cyan-500/30 shadow-2xl shadow-cyan-900/40">
        <h2 className="text-2xl font-tech text-center mb-8 text-cyan-300">
          本次能量输入
        </h2>
        
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <div className="relative">
            <input
              type="number"
              value={countStr}
              onChange={(e) => setCountStr(e.target.value)}
              placeholder="0"
              className="w-full bg-slate-900/80 border-2 border-cyan-600 text-center text-5xl font-bold text-white py-6 rounded-xl focus:outline-none focus:border-fuchsia-500 transition-colors placeholder-slate-600 font-mono"
              autoFocus
            />
            <span className="absolute right-4 bottom-4 text-slate-500 text-sm">REPS</span>
          </div>

          <button
            type="submit"
            disabled={!countStr}
            className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-4 rounded-xl text-xl tracking-widest uppercase transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-cyan-600/30"
          >
            确认上传
          </button>
        </form>
      </div>
    </div>
  );
};

export default InputView;