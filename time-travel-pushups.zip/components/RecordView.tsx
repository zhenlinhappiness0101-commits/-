import React, { useRef, useState, useEffect } from 'react';
import { getChineseWeekday, formatFullDate } from '../utils/dateUtils';
import { AppState } from '../types';

interface RecordViewProps {
  onFinishRecording: (videoBlob: Blob | null) => void;
}

const RecordView: React.FC<RecordViewProps> = ({ onFinishRecording }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [recording, setRecording] = useState(false);
  const [chunks, setChunks] = useState<Blob[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());

  // Clock ticker
  useEffect(() => {
    const timer = setInterval(() => setCurrentDate(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Initialize Camera
  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user' },
          audio: true
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Error accessing camera:", err);
        alert("请允许访问摄像头以使用录制功能");
      }
    };
    startCamera();

    return () => {
      // Cleanup stream
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleStartRecording = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      const localChunks: Blob[] = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) localChunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(localChunks, { type: 'video/mp4' });
        
        // Auto download logic
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `pushup_record_${new Date().getTime()}.mp4`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        
        // Navigate away
        onFinishRecording(blob);
      };

      mediaRecorder.start();
      setRecording(true);
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  const toggleRecording = () => {
    if (recording) {
      handleStopRecording();
    } else {
      handleStartRecording();
    }
  };

  return (
    <div className="relative h-full w-full flex flex-col items-center justify-between bg-black overflow-hidden">
      {/* Background Video Stream */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="absolute top-0 left-0 w-full h-full object-cover z-0"
      />

      {/* Overlay UI */}
      <div className="z-10 w-full pt-12 pb-8 px-6 flex flex-col h-full justify-between bg-gradient-to-b from-black/60 via-transparent to-black/80">
        
        {/* Header Text */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold font-tech text-cyan-400 neon-text tracking-wider">
            知行合一的星期{getChineseWeekday(currentDate)}
          </h1>
          <p className="text-lg text-cyan-200 font-mono tracking-widest opacity-90">
            {formatFullDate(currentDate)}
          </p>
        </div>

        {/* Recording Control */}
        <div className="flex flex-col items-center gap-4 mb-8">
            <p className="text-sm text-cyan-300/80 uppercase tracking-widest">
                {recording ? "REC • 录制中" : "点击开始 / 再次点击结束并保存"}
            </p>
            <button
                onClick={toggleRecording}
                className={`
                    w-20 h-20 rounded-full border-4 border-white flex items-center justify-center
                    transition-all duration-300 shadow-lg
                    ${recording ? 'bg-transparent scale-110 border-red-500 shadow-red-500/50' : 'bg-transparent border-cyan-400 hover:scale-105'}
                `}
            >
                <div className={`
                    rounded-full transition-all duration-300
                    ${recording ? 'w-8 h-8 bg-red-600 rounded-sm' : 'w-16 h-16 bg-red-600'}
                `}></div>
            </button>
        </div>
      </div>
    </div>
  );
};

export default RecordView;