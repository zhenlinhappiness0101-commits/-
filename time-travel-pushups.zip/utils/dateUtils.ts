import { BASE_DATE_STRING } from '../types';

export const getChineseWeekday = (date: Date): string => {
  const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
  return weekdays[date.getDay()];
};

export const formatFullDate = (date: Date): string => {
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
  const h = date.getHours().toString().padStart(2, '0');
  const min = date.getMinutes().toString().padStart(2, '0');
  const s = date.getSeconds().toString().padStart(2, '0');
  return `${y}年${m}月${d}日 ${h}:${min}:${s}`;
};

export const calculateReachDate = (totalPushups: number): string => {
  const base = new Date(BASE_DATE_STRING);
  // Logic: 1 pushup = 1 day progress
  base.setDate(base.getDate() + totalPushups);
  
  const y = base.getFullYear();
  const m = base.getMonth() + 1;
  const d = base.getDate();
  
  return `${y}年${m}月${d}日`;
};

export const formatDateForHistory = (isoString: string): string => {
  const date = new Date(isoString);
  return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
};