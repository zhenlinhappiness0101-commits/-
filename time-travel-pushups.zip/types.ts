export interface HistoryItem {
  id: string;
  date: string; // ISO string for the record date
  count: number;
  timestamp: number;
}

export enum AppState {
  RECORDING = 'RECORDING',
  INPUT = 'INPUT',
  COUNTDOWN = 'COUNTDOWN',
  RESULT = 'RESULT',
  HISTORY = 'HISTORY'
}

export const BASE_DATE_STRING = "2025-11-22"; // The anchor date