// A royalty-free energetic sci-fi/success sound
export const SUCCESS_MUSIC_URL = "https://cdn.pixabay.com/audio/2024/02/07/audio_40212f4581.mp3"; 

export const THEME_COLORS = {
  primary: 'cyan-400',
  secondary: 'fuchsia-500',
  bg: 'slate-900'
};