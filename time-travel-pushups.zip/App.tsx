import React, { useState } from 'react';
import { AppState } from './types';
import RecordView from './components/RecordView';
import InputView from './components/InputView';
import CountdownView from './components/CountdownView';
import ResultView from './components/ResultView';
import HistoryView from './components/HistoryView';
import { saveHistoryItem } from './services/storageService';

const App: React.FC = () => {
  const [currentState, setCurrentState] = useState<AppState>(AppState.RECORDING);
  const [currentSessionCount, setCurrentSessionCount] = useState<number>(0);

  // Transition Logic
  const handleFinishRecording = (blob: Blob | null) => {
    // Blob is saved in RecordView via download link, just transition here
    setCurrentState(AppState.INPUT);
  };

  const handleInputConfirm = (count: number) => {
    setCurrentSessionCount(count);
    setCurrentState(AppState.COUNTDOWN);
  };

  const handleCountdownComplete = () => {
    // Save data only when countdown completes and we enter result view
    const newItem = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      count: currentSessionCount,
      timestamp: Date.now()
    };
    saveHistoryItem(newItem);
    
    setCurrentState(AppState.RESULT);
  };

  const handleNavigateHistory = () => {
    setCurrentState(AppState.HISTORY);
  };

  const handleBackToResult = () => {
    // Optionally go back to result or restart. Let's restart flow or stay in result.
    // Based on user flow, maybe going back to result is cleaner, or back to record for next day.
    // Let's go back to Record to allow a "new cycle" effectively, or Result.
    // Given the prompt structure, page 4 is accessible from page 3.
    setCurrentState(AppState.RESULT);
  };

  return (
    <div className="h-screen w-screen overflow-hidden bg-slate-900 text-white font-sans">
      {currentState === AppState.RECORDING && (
        <RecordView onFinishRecording={handleFinishRecording} />
      )}
      
      {currentState === AppState.INPUT && (
        <InputView onConfirm={handleInputConfirm} />
      )}
      
      {currentState === AppState.COUNTDOWN && (
        <CountdownView onComplete={handleCountdownComplete} />
      )}
      
      {currentState === AppState.RESULT && (
        <ResultView 
          onNavigateHistory={handleNavigateHistory} 
          currentSessionCount={currentSessionCount}
        />
      )}
      
      {currentState === AppState.HISTORY && (
        <HistoryView onBack={handleBackToResult} />
      )}
    </div>
  );
};

export default App;