import React, { useEffect, useRef, useState } from 'react';
import { calculateReachDate } from '../utils/dateUtils';
import { getTotalPushups } from '../services/storageService';
import { SUCCESS_MUSIC_URL, THEME_COLORS } from '../constants';
import { BASE_DATE_STRING } from '../types';

interface ResultViewProps {
  onNavigateHistory: () => void;
  currentSessionCount: number;
}

const ResultView: React.FC<ResultViewProps> = ({ onNavigateHistory, currentSessionCount }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [total, setTotal] = useState(0);
  const [reachedDate, setReachedDate] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const totalPushups = getTotalPushups();
    setTotal(totalPushups);
    setReachedDate(calculateReachDate(totalPushups));

    // Play Music
    if (audioRef.current) {
      audioRef.current.volume = 0.5;
      audioRef.current.play().catch(e => console.log("Auto-play prevented by browser policy", e));
    }
    
    // Simple particle animation for visual flair
    const canvas = canvasRef.current;
    if (canvas) {
        const ctx = canvas.getContext('2d');
        if(!ctx) return;
        
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        const particles: any[] = [];
        for(let i=0; i<50; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vy: -1 - Math.random(),
                size: Math.random() * 3,
                color: Math.random() > 0.5 ? '#22d3ee' : '#d946ef'
            })
        }
        
        const animate = () => {
            ctx.clearRect(0,0, canvas.width, canvas.height);
            particles.forEach(p => {
                p.y += p.vy;
                if(p.y < 0) p.y = canvas.height;
                ctx.fillStyle = p.color;
                ctx.globalAlpha = 0.6;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });
            requestAnimationFrame(animate);
        }
        animate();
    }
  }, [currentSessionCount]);

  return (
    <div className="relative h-full w-full flex flex-col items-center justify-center p-6 bg-slate-900 overflow-hidden">
      <audio ref={audioRef} src={SUCCESS_MUSIC_URL} loop />
      <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />

      <div className="z-10 w-full max-w-lg text-center space-y-8 animate-fade-in-up">
        
        <div className="space-y-2">
            <h3 className="text-cyan-200 text-lg uppercase tracking-[0.3em]">System Sync Complete</h3>
            <p className="text-slate-400 text-sm">Base Timeline: {BASE_DATE_STRING}</p>
        </div>

        <div className="bg-white/5 backdrop-blur-md border border-cyan-500/40 p-8 rounded-2xl neon-box transform hover:scale-105 transition-transform duration-500">
          <p className="text-cyan-300 text-xl mb-4 font-tech">每日一撑 • 抵达未来</p>
          <div className="space-y-4">
            <p className="text-slate-300 text-sm">目前累计进度已到达</p>
            <h1 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-fuchsia-500 font-tech leading-tight">
              {reachedDate}
            </h1>
          </div>
          <div className="mt-6 pt-6 border-t border-slate-700">
              <p className="text-fuchsia-300 font-bold">Total Power: {total} Units</p>
          </div>
        </div>

        <button 
          onClick={onNavigateHistory}
          className="mt-8 px-8 py-3 bg-slate-800/80 border border-slate-600 text-slate-300 rounded-full text-sm hover:bg-slate-700 hover:text-white transition-colors uppercase tracking-wider"
        >
          查看详细数据
        </button>
      </div>
    </div>
  );
};

export default ResultView;